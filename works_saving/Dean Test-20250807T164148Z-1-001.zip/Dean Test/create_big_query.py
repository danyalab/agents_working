# create_bigquery_tables.py
# Creates BigQuery dataset and tables for the hackathon

from google.cloud import bigquery
import os

# Configuration
PROJECT_ID = "wealthaid-2-18d7"  # Replace with your project
DATASET_ID = "cio_hackathon"     # Simplified for hackathon

def create_dataset_and_tables():
    client = bigquery.Client(project=PROJECT_ID)
    
    # Step 1: Create dataset
    dataset_id = f"{PROJECT_ID}.{DATASET_ID}"
    
    try:
        dataset = bigquery.Dataset(dataset_id)
        dataset.location = "US"
        dataset = client.create_dataset(dataset, exists_ok=True)
        print(f"✅ Dataset {dataset_id} created or already exists")
    except Exception as e:
        print(f"❌ Error creating dataset: {e}")
        return False
    
    # Step 2: Create client_data table
    client_table_sql = f"""
    CREATE OR REPLACE TABLE `{PROJECT_ID}.{DATASET_ID}.client_data` (
      ClientID STRING NOT NULL,
      Client_Name STRING,
      as_of_date DATE,
      
      -- Asset Allocations (percentages)
      US_LC FLOAT64,
      US_SMID FLOAT64, 
      US_LC_Tech FLOAT64,
      US_LC_exTech FLOAT64,
      InvGrade FLOAT64,
      Cash FLOAT64,
      International FLOAT64,
      
      -- Client Profile
      Age INT64,
      Risk_Tolerance STRING,
      Estimated_Net_Worth FLOAT64,
      Investment_Experience STRING,
      Financial_Goals STRING
    )
    """
    
    try:
        client.query(client_table_sql).result()
        print("✅ client_data table created")
    except Exception as e:
        print(f"❌ Error creating client_data table: {e}")
        return False
    
    # Step 3: Create CIO themes table  
    themes_table_sql = f"""
    CREATE OR REPLACE TABLE `{PROJECT_ID}.{DATASET_ID}.cio_themes` (
      theme_id STRING NOT NULL,
      theme_name STRING,
      theme_category STRING,
      cio_recommendation STRING,
      target_min FLOAT64,
      target_max FLOAT64,
      confidence_score FLOAT64,
      theme_description STRING,
      extraction_date DATE
    )
    """
    
    try:
        client.query(themes_table_sql).result()
        print("✅ cio_themes table created")
    except Exception as e:
        print(f"❌ Error creating cio_themes table: {e}")
        return False
    
    # Step 4: Create analysis results table
    results_table_sql = f"""
    CREATE OR REPLACE TABLE `{PROJECT_ID}.{DATASET_ID}.client_analysis` (
      ClientID STRING,
      Client_Name STRING,
      analysis_type STRING,
      deviation_score FLOAT64,
      priority_score FLOAT64,
      recommendation STRING,
      talking_points STRING,
      analysis_date DATE
    )
    """
    
    try:
        client.query(results_table_sql).result()
        print("✅ client_analysis table created")
    except Exception as e:
        print(f"❌ Error creating client_analysis table: {e}")
        return False
        
    print("\n🎉 All BigQuery tables created successfully!")
    print(f"📊 Dataset: {dataset_id}")
    print("📋 Tables: client_data, cio_themes, client_analysis")
    
    return True

if __name__ == "__main__":
    print("🏗️  Creating BigQuery Tables for Hackathon...")
    success = create_dataset_and_tables()
    
    if success:
        print("\n✅ Ready for next step: python generate_sample_data.py")
    else:
        print("\n❌ Fix errors above before continuing")
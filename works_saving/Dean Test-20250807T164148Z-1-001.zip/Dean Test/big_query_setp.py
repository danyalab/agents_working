# hackathon_setup.py
# Run this first to set up your environment

import subprocess
import sys
import os

def install_requirements():
    """Install required packages"""
    packages = [
        "google-cloud-bigquery",
        "google-cloud-storage", 
        "google-genai",
        "pandas",
        "numpy"
    ]
    
    for package in packages:
        subprocess.check_call([sys.executable, "-m", "pip", "install", package])
        print(f"✅ Installed {package}")

def setup_environment():
    """Set up environment variables"""
    print("\n🔧 Environment Setup:")
    print("1. Make sure you have GOOGLE_APPLICATION_CREDENTIALS set")
    print("2. Your service account needs BigQuery Admin and Storage Admin roles")
    print("3. Run: gcloud auth application-default login")
    
    # Check if credentials are available
    if not os.environ.get('GOOGLE_APPLICATION_CREDENTIALS'):
        print("⚠️  Set GOOGLE_APPLICATION_CREDENTIALS to your service account key file")
    else:
        print("✅ Found GOOGLE_APPLICATION_CREDENTIALS")

def print_next_steps():
    """Print what to do next"""
    print("\n📋 Next Steps:")
    print("1. Run: python create_bigquery_tables.py")
    print("2. Run: python generate_sample_data.py") 
    print("3. Run: python cio_theme_extractor.py")
    print("4. Run: python hackathon_demo.py")

if __name__ == "__main__":
    print("🚀 Hackathon Setup Starting...")
    install_requirements()
    setup_environment()
    print_next_steps()
    print("\n🎉 Setup complete! Move to next script.")
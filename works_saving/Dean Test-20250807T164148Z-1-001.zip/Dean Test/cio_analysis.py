# cio_analysis.py
# Core analysis engine that matches clients to CIO themes

import pandas as pd
import numpy as np
from google.cloud import bigquery
from google import genai
import vertexai
from typing import Dict, List, Tuple
from datetime import date
import json

PROJECT_ID = "wealthaid-2-18d7"
DATASET_ID = "cio_hackathon"
LOCATION = "us-central1"

# Initialize AI clients
vertexai.init(project=PROJECT_ID, location=LOCATION)
genai_client = genai.Client(vertexai=True, project=PROJECT_ID, location=LOCATION)
bq_client = bigquery.Client(project=PROJECT_ID)

class CIOAnalysisEngine:
    
    def __init__(self):
        self.analysis_results = []
    
    def get_client_data(self) -> pd.DataFrame:
        """Fetch client data from BigQuery"""
        query = f"""
        SELECT * FROM `{PROJECT_ID}.{DATASET_ID}.client_data`
        WHERE as_of_date = (SELECT MAX(as_of_date) FROM `{PROJECT_ID}.{DATASET_ID}.client_data`)
        """
        df = bq_client.query(query).to_dataframe()
        
        print(f"🔍 Available columns in client_data: {list(df.columns)}")
        
        # Clean up duplicate Client_Name columns
        if 'Client_Name_x' in df.columns and 'Client_Name_y' in df.columns:
            # Use the non-null version or prefer _y (from profile data)
            df['Client_Name'] = df['Client_Name_y'].fillna(df['Client_Name_x'])
            df = df.drop(['Client_Name_x', 'Client_Name_y'], axis=1)
        elif 'Client_Name_x' in df.columns:
            df['Client_Name'] = df['Client_Name_x']
            df = df.drop(['Client_Name_x'], axis=1)
        elif 'Client_Name_y' in df.columns:
            df['Client_Name'] = df['Client_Name_y'] 
            df = df.drop(['Client_Name_y'], axis=1)
        
        # Add missing columns with defaults if needed
        if 'Client_Name' not in df.columns:
            if 'ClientID' in df.columns:
                df['Client_Name'] = df['ClientID'].apply(lambda x: f"Client {x}")
            else:
                df['Client_Name'] = [f"Client_{i+1}" for i in range(len(df))]
        
        print(f"📊 Sample data:")
        sample_cols = ['ClientID', 'Client_Name', 'US_LC_Tech', 'Cash', 'Risk_Tolerance', 'Estimated_Net_Worth']
        available_sample_cols = [col for col in sample_cols if col in df.columns]
        print(df[available_sample_cols].head(2).to_string(index=False))
        
        return df
    
    def get_cio_themes(self) -> pd.DataFrame:
        """Fetch CIO themes from BigQuery"""
        query = f"""
        SELECT * FROM `{PROJECT_ID}.{DATASET_ID}.cio_themes`
        ORDER BY confidence_score DESC
        """
        return bq_client.query(query).to_dataframe()
    
    def analyze_tech_exposure(self, clients_df: pd.DataFrame, themes_df: pd.DataFrame) -> pd.DataFrame:
        """Analyze client tech exposure vs CIO recommendation"""
        
        # Get tech theme
        tech_theme = themes_df[themes_df['theme_name'].str.contains('Technology', case=False)]
        if tech_theme.empty:
            print("No tech theme found")
            return pd.DataFrame()
            
        tech_rec = tech_theme.iloc[0]
        target_min, target_max = tech_rec['target_min'], tech_rec['target_max']
        
        print(f"📊 Analyzing Tech Exposure vs CIO Target: {target_min}-{target_max}%")
        
        # Check required columns exist
        required_cols = ['ClientID', 'US_LC_Tech']
        missing_cols = [col for col in required_cols if col not in clients_df.columns]
        if missing_cols:
            print(f"❌ Missing required columns: {missing_cols}")
            return pd.DataFrame()
        
        results = []
        for _, client in clients_df.iterrows():
            tech_allocation = client['US_LC_Tech'] if pd.notna(client['US_LC_Tech']) else 0
            
            # Calculate deviation
            if tech_allocation > target_max:
                deviation = tech_allocation - target_max
                status = "OVERWEIGHT"
                action = "REDUCE_TECH"
            elif tech_allocation < target_min:
                deviation = target_min - tech_allocation  
                status = "UNDERWEIGHT"
                action = "INCREASE_TECH"
            else:
                deviation = 0
                status = "ON_TARGET"
                action = "MONITOR"
            
            # Get client name safely
            client_name = client.get('Client_Name', f"Client_{client['ClientID']}")
            
            # Get net worth safely
            net_worth = client.get('Estimated_Net_Worth', 1000000)  # Default 1M if missing
            
            # Priority scoring (deviation * portfolio size)
            priority_score = deviation * (net_worth / 1000000)
            
            results.append({
                'ClientID': client['ClientID'],
                'Client_Name': client_name,
                'Current_Tech_Pct': tech_allocation,
                'Target_Range': f"{target_min}-{target_max}%",
                'Deviation': round(deviation, 2),
                'Status': status,
                'Action': action,
                'Priority_Score': round(priority_score, 2),
                'Net_Worth': net_worth,
                'Risk_Tolerance': client.get('Risk_Tolerance', 'Unknown'),
                'Age': client.get('Age', 0)
            })
        
        return pd.DataFrame(results)
    
    def analyze_international_exposure(self, clients_df: pd.DataFrame, themes_df: pd.DataFrame) -> pd.DataFrame:
        """Analyze international allocation vs CIO recommendation"""
        
        intl_theme = themes_df[themes_df['theme_name'].str.contains('International', case=False)]
        if intl_theme.empty:
            print("⚠️ No international theme found, skipping analysis")
            return pd.DataFrame()
            
        intl_rec = intl_theme.iloc[0]
        target_min, target_max = intl_rec['target_min'], intl_rec['target_max']
        
        print(f"🌍 Analyzing International Exposure vs CIO Target: {target_min}-{target_max}%")
        
        # Check if International column exists
        if 'International' not in clients_df.columns:
            print("⚠️ No International column found, skipping analysis")
            return pd.DataFrame()
        
        results = []
        for _, client in clients_df.iterrows():
            intl_allocation = client['International'] if pd.notna(client['International']) else 0
            
            if intl_allocation > target_max:
                deviation = intl_allocation - target_max
                status = "OVERWEIGHT"
                action = "REDUCE_INTERNATIONAL"
            elif intl_allocation < target_min:
                deviation = target_min - intl_allocation
                status = "UNDERWEIGHT" 
                action = "INCREASE_INTERNATIONAL"
            else:
                deviation = 0
                status = "ON_TARGET"
                action = "MONITOR"
            
            client_name = client.get('Client_Name', f"Client_{client['ClientID']}")
            net_worth = client.get('Estimated_Net_Worth', 1000000)
            priority_score = deviation * (net_worth / 1000000)
            
            results.append({
                'ClientID': client['ClientID'],
                'Client_Name': client_name, 
                'Current_Intl_Pct': intl_allocation,
                'Target_Range': f"{target_min}-{target_max}%",
                'Deviation': round(deviation, 2),
                'Status': status,
                'Action': action,
                'Priority_Score': round(priority_score, 2),
                'Net_Worth': net_worth
            })
        
        return pd.DataFrame(results)
    
    def analyze_cash_levels(self, clients_df: pd.DataFrame, themes_df: pd.DataFrame) -> pd.DataFrame:
        """Analyze cash allocation vs CIO and risk tolerance"""
        
        cash_theme = themes_df[themes_df['theme_name'].str.contains('Cash', case=False)]
        
        print("💰 Analyzing Cash Levels vs CIO + Risk Tolerance")
        
        # Check if required columns exist
        if 'Cash' not in clients_df.columns:
            print("⚠️ No Cash column found, skipping analysis")
            return pd.DataFrame()
        
        results = []
        for _, client in clients_df.iterrows():
            cash_allocation = client['Cash'] if pd.notna(client['Cash']) else 0
            risk_tolerance = client.get('Risk_Tolerance', 'Moderate')
            
            # Adjust targets based on risk tolerance
            if risk_tolerance == 'Conservative' or risk_tolerance == 'Low':
                target_min, target_max = 15, 25
            elif risk_tolerance == 'Aggressive' or risk_tolerance == 'High':
                target_min, target_max = 5, 15
            else:  # Moderate/Medium
                target_min, target_max = 8, 20
                
            # If we have CIO cash theme, use those targets
            if not cash_theme.empty:
                cio_min = cash_theme.iloc[0]['target_min']
                cio_max = cash_theme.iloc[0]['target_max']
                # Blend CIO and risk-based targets
                target_min = (target_min + cio_min) / 2
                target_max = (target_max + cio_max) / 2
            
            if cash_allocation > target_max:
                deviation = cash_allocation - target_max
                status = "TOO_MUCH_CASH"
                action = "DEPLOY_CASH"
            elif cash_allocation < target_min:
                deviation = target_min - cash_allocation
                status = "TOO_LITTLE_CASH" 
                action = "INCREASE_CASH"
            else:
                deviation = 0
                status = "APPROPRIATE_CASH"
                action = "MONITOR"
            
            client_name = client.get('Client_Name', f"Client_{client['ClientID']}")
            net_worth = client.get('Estimated_Net_Worth', 1000000)
            priority_score = deviation * (net_worth / 1000000)
            
            results.append({
                'ClientID': client['ClientID'],
                'Client_Name': client_name,
                'Current_Cash_Pct': cash_allocation,
                'Target_Range': f"{target_min:.1f}-{target_max:.1f}%",
                'Deviation': round(deviation, 2),
                'Status': status,
                'Action': action,
                'Priority_Score': round(priority_score, 2),
                'Risk_Tolerance': risk_tolerance
            })
        
        return pd.DataFrame(results)
    
    def generate_talking_points(self, analysis_result: Dict) -> str:
        """Generate AI-powered talking points for advisors"""
        
        # Get values safely with defaults
        client_name = analysis_result.get('Client_Name', 'Client')
        net_worth = analysis_result.get('Net_Worth', 1000000)
        status = analysis_result.get('Status', 'Needs Review')
        target_range = analysis_result.get('Target_Range', 'See CIO guidance')
        deviation = analysis_result.get('Deviation', 'N/A')
        
        # Find the current allocation from various possible fields
        current_allocation = (analysis_result.get('Current_Tech_Pct') or 
                            analysis_result.get('Current_Intl_Pct') or 
                            analysis_result.get('Current_Cash_Pct') or 
                            'N/A')
        
        # Format net worth safely
        try:
            net_worth_formatted = f"${float(net_worth):,.0f}" if net_worth != 'Unknown' else "Unknown"
        except (ValueError, TypeError):
            net_worth_formatted = "Unknown"
        
        prompt = f"""
        You are a financial advisor's assistant. Generate 3-4 specific talking points for this client analysis:
        
        Client: {client_name}
        Net Worth: {net_worth_formatted}
        Issue: {status}
        Current Allocation: {current_allocation}%
        Target Range: {target_range}
        Deviation: {deviation}%
        
        Make talking points:
        1. Specific and actionable
        2. Reference current market conditions 
        3. Appropriate for client's profile
        4. Include concrete next steps
        
        Format as bullet points, keep concise.
        """
        
        try:
            response = genai_client.models.generate_content(
                model="gemini-2.0-flash-001",
                contents=prompt
            )
            return response.text.strip()
        except Exception as e:
            print(f"⚠️ AI talking points failed: {e}")
            # Return fallback talking points
            action = analysis_result.get('Action', 'review portfolio').lower().replace('_', ' ')
            return f"""• Discuss {action} strategy based on current market conditions
• Review portfolio alignment with CIO recommendations  
• Consider rebalancing to target range: {target_range}
• Schedule follow-up meeting in 2 weeks to monitor progress"""
    
    def run_comprehensive_analysis(self) -> Dict:
        """Run all analyses and generate prioritized client list"""
        
        print("🚀 Running Comprehensive CIO Analysis...")
        
        # Load data
        clients_df = self.get_client_data()
        themes_df = self.get_cio_themes()
        
        print(f"📊 Loaded {len(clients_df)} clients and {len(themes_df)} CIO themes")
        
        # Run individual analyses
        tech_analysis = self.analyze_tech_exposure(clients_df, themes_df)
        intl_analysis = self.analyze_international_exposure(clients_df, themes_df)
        cash_analysis = self.analyze_cash_levels(clients_df, themes_df)
        
        # Combine and prioritize
        all_issues = []
        
        # Process tech issues
        for _, row in tech_analysis[tech_analysis['Status'] != 'ON_TARGET'].iterrows():
            issue = row.to_dict()
            issue['Analysis_Type'] = 'TECH_ALLOCATION'
            issue['Talking_Points'] = self.generate_talking_points(issue)
            all_issues.append(issue)
        
        # Process international issues
        for _, row in intl_analysis[intl_analysis['Status'] != 'ON_TARGET'].iterrows():
            issue = row.to_dict()
            issue['Analysis_Type'] = 'INTERNATIONAL_ALLOCATION'
            issue['Talking_Points'] = self.generate_talking_points(issue)
            all_issues.append(issue)
            
        # Process cash issues
        for _, row in cash_analysis[cash_analysis['Status'] != 'APPROPRIATE_CASH'].iterrows():
            issue = row.to_dict()
            issue['Analysis_Type'] = 'CASH_ALLOCATION'
            issue['Talking_Points'] = self.generate_talking_points(issue)
            all_issues.append(issue)
        
        # Sort by priority score
        all_issues.sort(key=lambda x: x['Priority_Score'], reverse=True)
        
        # Save results to BigQuery
        self.save_analysis_results(all_issues)
        
        return {
            'total_clients_analyzed': len(clients_df),
            'clients_with_issues': len(all_issues),
            'tech_issues': len(tech_analysis[tech_analysis['Status'] != 'ON_TARGET']),
            'intl_issues': len(intl_analysis[intl_analysis['Status'] != 'ON_TARGET']),
            'cash_issues': len(cash_analysis[cash_analysis['Status'] != 'APPROPRIATE_CASH']),
            'top_priority_clients': all_issues[:10],
            'analysis_summaries': {
                'tech_analysis': tech_analysis,
                'intl_analysis': intl_analysis, 
                'cash_analysis': cash_analysis
            }
        }
    
    def save_analysis_results(self, issues: List[Dict]):
        """Save analysis results to BigQuery"""
        
        if not issues:
            return
            
        # Prepare for BigQuery
        rows = []
        for issue in issues:
            rows.append({
                'ClientID': issue['ClientID'],
                'Client_Name': issue['Client_Name'],
                'analysis_type': issue['Analysis_Type'],
                'deviation_score': issue['Deviation'],
                'priority_score': issue['Priority_Score'],
                'recommendation': issue['Action'],
                'talking_points': issue['Talking_Points'],
                'analysis_date': date.today()
            })
        
        # Upload to BigQuery
        table_id = f"{PROJECT_ID}.{DATASET_ID}.client_analysis"
        
        job_config = bigquery.LoadJobConfig(
            write_disposition="WRITE_TRUNCATE",
        )
        
        job = bq_client.load_table_from_dataframe(pd.DataFrame(rows), table_id, job_config=job_config)
        job.result()
        
        print(f"✅ Saved {len(rows)} analysis results to BigQuery")

def main():
    print("🎯 CIO Theme Matching Analysis - Hackathon Demo")
    print("=" * 60)
    
    # Run analysis
    analyzer = CIOAnalysisEngine()
    results = analyzer.run_comprehensive_analysis()
    
    # Display results
    print("\n📈 ANALYSIS COMPLETE!")
    print(f"   • Total clients analyzed: {results['total_clients_analyzed']}")
    print(f"   • Clients needing attention: {results['clients_with_issues']}")
    print(f"   • Tech allocation issues: {results['tech_issues']}")
    print(f"   • International exposure issues: {results['intl_issues']}")
    print(f"   • Cash level issues: {results['cash_issues']}")
    
    print(f"\n🔥 TOP 5 PRIORITY CLIENTS TO CALL TODAY:")
    for i, client in enumerate(results['top_priority_clients'][:5], 1):
        print(f"\n{i}. {client['Client_Name']} (Score: {client['Priority_Score']})")
        print(f"   Issue: {client['Status']}")
        print(f"   Current: {client.get('Current_Tech_Pct', client.get('Current_Intl_Pct', client.get('Current_Cash_Pct')))}%, Target: {client['Target_Range']}")
        print(f"   💰 Net Worth: ${client.get('Net_Worth', 0):,.0f}")
        print(f"   📞 Talking Points:")
        print(f"   {client['Talking_Points']}")
    
    print(f"\n✅ Ready for demo! Run: python hackathon_demo.py")
    return results

if __name__ == "__main__":
    main()
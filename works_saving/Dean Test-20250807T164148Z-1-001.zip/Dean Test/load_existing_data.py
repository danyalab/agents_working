# load_existing_data.py
# Phase 3 Replacement - Load your existing synthetic data from Cloud Storage

import pandas as pd
import numpy as np
from google.cloud import bigquery
from google.cloud import storage
import tempfile
import os
from datetime import date

# Configuration
PROJECT_ID = "wealthaid-2-18d7"  # Update to match your project
DATASET_ID = "cio_hackathon"
BUCKET_NAME = "synthetic_data_wealthaid"  # From your screenshot

def explore_data_files():
    """First, let's see what's in your data files"""
    storage_client = storage.Client()
    bucket = storage_client.bucket(BUCKET_NAME)
    
    # List CSV files
    csv_files = []
    
    print("📁 Found CSV files in your bucket:")
    for blob in bucket.list_blobs():
        if blob.name.endswith('.csv'):
            csv_files.append(blob.name)
            
            # Safely get size
            try:
                blob.reload()  # Refresh metadata
                size_kb = blob.size / 1024 if blob.size else 0
                print(f"   • {blob.name} ({size_kb:.1f} KB)")
            except Exception as e:
                print(f"   • {blob.name} (size unknown)")
    
    return csv_files

def load_and_examine_csv(bucket_name: str, file_name: str) -> pd.DataFrame:
    """Load CSV from Cloud Storage and examine structure"""
    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(file_name)
    
    # Download to temporary file
    with tempfile.NamedTemporaryFile(delete=False, suffix='.csv') as temp_file:
        blob.download_to_filename(temp_file.name)
        df = pd.read_csv(temp_file.name)
    
    os.unlink(temp_file.name)
    
    print(f"\n📊 Structure of {file_name}:")
    print(f"   Rows: {len(df)}")
    print(f"   Columns: {list(df.columns)}")
    print(f"   Sample data:")
    print(df.head(2).to_string(index=False))
    print()
    
    return df

def map_holdings_columns(holdings_df: pd.DataFrame) -> pd.DataFrame:
    """Map your holdings columns to our BigQuery schema"""
    print("🔧 Checking holdings data structure...")
    
    # Your data already has the perfect columns! Just clean up the values
    mapped_df = holdings_df.copy()
    
    # Convert percentage strings to floats if needed
    percentage_cols = ['Gold', 'US_LC', 'US_SMID', 'US_LC_Tech', 'US_LC_exTech', 'InvGrade', 'Munis', 'Cash']
    
    for col in percentage_cols:
        if col in mapped_df.columns:
            # Convert percentage strings like "40%" to 40.0
            if mapped_df[col].dtype == 'object':
                mapped_df[col] = mapped_df[col].str.replace('%', '').astype(float)
    
    # Convert date column if needed
    if 'as_of_date' in mapped_df.columns:
        mapped_df['as_of_date'] = pd.to_datetime(mapped_df['as_of_date'], format='%Y%m%d').dt.date
    
    # Add International column if missing (set to 0 for now)
    if 'International' not in mapped_df.columns:
        mapped_df['International'] = 0.0
    
    print(f"   ✅ Your data structure is perfect! Columns: {list(mapped_df.columns)}")
    print(f"   📊 Sample allocations after cleanup:")
    sample_cols = ['ClientID', 'US_LC_Tech', 'Cash', 'InvGrade']
    available_cols = [col for col in sample_cols if col in mapped_df.columns]
    if available_cols:
        print(mapped_df[available_cols].head(2).to_string(index=False))
    
    return mapped_df

def map_profile_columns(profile_df: pd.DataFrame) -> pd.DataFrame:
    """Select key profile columns - your data is already perfectly named!"""
    print("🔧 Selecting key profile columns...")
    
    # Your profile data already has perfect column names - just select what we need
    key_columns = [
        'ClientID', 'Client_Name', 'Age', 'Risk_Tolerance', 
        'Estimated_Net_Worth', 'Investment_Experience', 'Financial_Goals', 
        'Income', 'Assets_Under_Management'
    ]
    
    # Select only columns that exist
    available_columns = [col for col in key_columns if col in profile_df.columns]
    
    print(f"   ✅ Selected columns: {available_columns}")
    
    selected_df = profile_df[available_columns].copy()
    
    print(f"   📊 Sample profile data:")
    sample_cols = ['ClientID', 'Age', 'Risk_Tolerance', 'Estimated_Net_Worth']
    available_sample_cols = [col for col in sample_cols if col in selected_df.columns]
    if available_sample_cols:
        print(selected_df[available_sample_cols].head(2).to_string(index=False))
    
    return selected_df

def combine_client_data(holdings_df: pd.DataFrame, profile_df: pd.DataFrame) -> pd.DataFrame:
    """Combine holdings and profile data"""
    print("🔗 Combining holdings and profile data...")
    
    # Find common client identifier
    holdings_id_col = None
    profile_id_col = None
    
    for col in holdings_df.columns:
        if 'ClientID' in col or ('client' in col.lower() and 'id' in col.lower()):
            holdings_id_col = col
            break
    
    for col in profile_df.columns:
        if 'ClientID' in col or ('client' in col.lower() and 'id' in col.lower()):
            profile_id_col = col
            break
    
    if not holdings_id_col or not profile_id_col:
        print("⚠️  No common client ID found, using index-based matching")
        # Fallback: assume same order
        combined_df = pd.concat([holdings_df, profile_df], axis=1)
    else:
        print(f"   Joining on {holdings_id_col} = {profile_id_col}")
        combined_df = holdings_df.merge(
            profile_df, 
            left_on=holdings_id_col, 
            right_on=profile_id_col, 
            how='inner'
        )
    
    print(f"   Combined data shape: {combined_df.shape}")
    return combined_df

def create_cio_themes():
    """Create sample CIO themes (same as before)"""
    themes = [
        {
            'theme_id': 'TECH_UNDERWEIGHT_2024',
            'theme_name': 'Technology Sector Underweight',
            'theme_category': 'sector',
            'cio_recommendation': 'underweight',
            'target_min': 5.0,
            'target_max': 15.0,
            'confidence_score': 0.85,
            'theme_description': 'Given high valuations and rate environment, recommend reducing tech exposure to 5-15%',
            'extraction_date': date.today()
        },
        {
            'theme_id': 'INTL_OVERWEIGHT_2024', 
            'theme_name': 'International Developed Markets Overweight',
            'theme_category': 'geography',
            'cio_recommendation': 'overweight', 
            'target_min': 25.0,
            'target_max': 35.0,
            'confidence_score': 0.75,
            'theme_description': 'International markets offer better value and diversification. Target 25-35% allocation',
            'extraction_date': date.today()
        },
        {
            'theme_id': 'CASH_TACTICAL_2024',
            'theme_name': 'Tactical Cash Position',
            'theme_category': 'asset_class', 
            'cio_recommendation': 'overweight',
            'target_min': 10.0,
            'target_max': 20.0,
            'confidence_score': 0.70,
            'theme_description': 'Maintain elevated cash for opportunities. Target 10-20% depending on risk tolerance',
            'extraction_date': date.today()
        }
    ]
    
    return pd.DataFrame(themes)

def upload_to_bigquery(df: pd.DataFrame, table_name: str):
    """Upload dataframe to BigQuery with better error handling"""
    client = bigquery.Client(project=PROJECT_ID)
    table_id = f"{PROJECT_ID}.{DATASET_ID}.{table_name}"
    
    # Clean up the dataframe before uploading
    clean_df = df.copy()
    
    # Convert any date columns to strings for BigQuery compatibility
    for col in clean_df.columns:
        if clean_df[col].dtype == 'object':
            # Check if it's a date column
            if 'date' in col.lower():
                clean_df[col] = clean_df[col].astype(str)
    
    # Remove any duplicate columns (keep first occurrence)
    clean_df = clean_df.loc[:,~clean_df.columns.duplicated()]
    
    print(f"   📊 Uploading {len(clean_df)} rows x {len(clean_df.columns)} columns")
    print(f"   📋 Columns: {list(clean_df.columns)}")
    
    job_config = bigquery.LoadJobConfig(
        write_disposition="WRITE_TRUNCATE",
        autodetect=True,  # Let BigQuery detect schema
        source_format=bigquery.SourceFormat.CSV,
    )
    
    try:
        job = client.load_table_from_dataframe(clean_df, table_id, job_config=job_config)
        job.result()  # Wait for job to complete
        
        print(f"✅ Successfully uploaded {len(clean_df)} rows to {table_name}")
        
    except Exception as e:
        print(f"❌ BigQuery upload error: {e}")
        print(f"   Data types: {clean_df.dtypes}")
        
        # Try a simplified version with just key columns
        if table_name == 'client_data':
            essential_cols = ['ClientID', 'Client_Name', 'US_LC_Tech', 'Cash', 'InvGrade', 'Age', 'Risk_Tolerance', 'Estimated_Net_Worth']
            available_essential = [col for col in essential_cols if col in clean_df.columns]
            
            if available_essential:
                print(f"   🔄 Trying simplified upload with: {available_essential}")
                simple_df = clean_df[available_essential].copy()
                
                job = client.load_table_from_dataframe(simple_df, table_id, job_config=job_config)
                job.result()
                print(f"✅ Simplified upload successful: {len(simple_df)} rows")
            else:
                raise e
        else:
            raise e

def main():
    print("🚀 Loading Your Existing Synthetic Data from Cloud Storage")
    print("=" * 60)
    
    # Step 0: Check if BigQuery tables exist
    print("🔍 Checking BigQuery setup...")
    client = bigquery.Client(project=PROJECT_ID)
    
    try:
        # Test if dataset exists
        dataset_id = f"{PROJECT_ID}.{DATASET_ID}"
        client.get_dataset(dataset_id)
        print(f"✅ Dataset {DATASET_ID} exists")
    except Exception as e:
        print(f"❌ Dataset {DATASET_ID} not found. Please run: python create_bigquery_tables.py")
        return
    
    # Step 1: Explore your data files
    csv_files = explore_data_files()
    
    # Step 2: Load and examine the key files
    holdings_df = None
    profile_df = None
    
    # Look for client holdings file
    holdings_files = [f for f in csv_files if 'holding' in f.lower()]
    if holdings_files:
        holdings_df = load_and_examine_csv(BUCKET_NAME, holdings_files[0])
        holdings_df = map_holdings_columns(holdings_df)
    
    # Look for client profile file  
    profile_files = [f for f in csv_files if 'profile' in f.lower()]
    if profile_files:
        profile_df = load_and_examine_csv(BUCKET_NAME, profile_files[0])
        profile_df = map_profile_columns(profile_df)
    
    # Step 3: Combine the data
    if holdings_df is not None and profile_df is not None:
        print("🔗 Combining holdings and profile data...")
        combined_df = combine_client_data(holdings_df, profile_df)
    elif holdings_df is not None:
        print("📊 Using holdings data only...")
        combined_df = holdings_df
        
        # Add some default profile columns
        if 'Age' not in combined_df.columns:
            combined_df['Age'] = 45  # Default age
        if 'Risk_Tolerance' not in combined_df.columns:
            combined_df['Risk_Tolerance'] = 'Moderate'
        if 'Estimated_Net_Worth' not in combined_df.columns:
            combined_df['Estimated_Net_Worth'] = 1000000  # Default net worth
            
    elif profile_df is not None:
        print("👤 Using profile data only...")  
        combined_df = profile_df
    else:
        print("❌ No client data files found!")
        return
    
    # Remove duplicate ClientID rows (keep most recent)
    if 'as_of_date' in combined_df.columns:
        combined_df = combined_df.sort_values('as_of_date').groupby('ClientID').tail(1)
        print(f"   📅 Kept most recent records: {len(combined_df)} unique clients")
    
    # Step 4: Create CIO themes
    themes_df = create_cio_themes()
    
    # Step 5: Upload to BigQuery
    print("\n📤 Uploading to BigQuery...")
    
    try:
        upload_to_bigquery(combined_df, "client_data")
        upload_to_bigquery(themes_df, "cio_themes")
        
        print("\n🎉 Your existing data loaded successfully!")
        print(f"✅ Client records: {len(combined_df)}")
        print(f"✅ CIO themes: {len(themes_df)}")
        
        # Show sample of loaded data
        print("\n📋 Sample of loaded client data:")
        display_cols = [col for col in combined_df.columns if col in ['ClientID', 'Client_Name', 'US_LC_Tech', 'Cash', 'Risk_Tolerance', 'Age', 'Estimated_Net_Worth']]
        if display_cols:
            print(combined_df[display_cols].head().to_string(index=False))
        
        print("\n✅ Ready for next step: python cio_analysis.py")
        
    except Exception as e:
        print(f"❌ Error uploading data: {e}")
        print("\n🔧 Troubleshooting:")
        print("1. Make sure you ran: python create_bigquery_tables.py")
        print("2. Check your PROJECT_ID in the script matches your Google Cloud project")
        print("3. Verify BigQuery permissions with: bq ls")
        print(f"4. Current PROJECT_ID in script: {PROJECT_ID}")
        
        # Show data sample for debugging
        print(f"\n📊 Data sample for debugging:")
        print(f"Combined data shape: {combined_df.shape}")
        print(f"Columns: {list(combined_df.columns)}")
        if len(combined_df) > 0:
            print(combined_df.head(1).to_string())

if __name__ == "__main__":
    main()